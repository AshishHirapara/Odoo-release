from datetime import date
import datetime
from tokenize import group
from odoo import api, fields, models
from odoo.exceptions import UserError
import os

REQUEST_STATES = [
    ('draft', 'Draft'),
    ('in_progress', 'Confirmed'),
    ('hr_approval', 'Hr Approval' ),
    ('manager_approval', 'Manager Approval' ),
    ('rejected', 'Rejected'),
    ('closed', 'Closed'),
]

class HrEmployeeRequest(models.Model):
    _name = 'hr.employee.position.request'
    _description = 'Employees Position Request'
    

    employee_id = fields.Many2one('hr.employee', string="Company employee", required=True)
    job_title = fields.Char(related='employee_id.job_title', related_sudo=False, tracking=True)
    work_phone = fields.Char(related='employee_id.work_phone', related_sudo=False, tracking=True)
    work_email = fields.Char(related='employee_id.work_email', related_sudo=False, tracking=True)
    department_id = fields.Many2one(related='employee_id.department_id', readonly=False, related_sudo=False, tracking=True)
    work_location = fields.Char(related='employee_id.work_location', related_sudo=False, tracking=True)
    employee_parent_id = fields.Many2one('hr.employee',related='employee_id.parent_id', string='Manager', related_sudo=False, tracking=True)
    coach_id = fields.Many2one('hr.employee', related='employee_id.coach_id', string='Coach',related_sudo=False, tracking=True)
    state = fields.Selection(REQUEST_STATES,
                              'Status', tracking=True, required=True,
                              copy=False, default='draft')
    contract_id = fields.Many2one('hr.contract',related='employee_id.contract_id', string='Current Contract', help='Current contract of the employee', related_sudo=False, tracking=True)
    
    job_id = fields.Many2one('hr.job', 'Job Position')
    hr_responsible_user_id = fields.Many2one('res.users', related='contract_id.hr_responsible_id',tracking=True,
        help='Person responsible for validating the employee\'s contracts.')

    user_id = fields.Many2one('res.users')
    requested_position = fields.Many2one('hr.job','Requested Job Position', required=True)
    requested_department = fields.Many2one('hr.department', 'Requested Department')
    company_id = fields.Many2one('res.company', default=lambda self: self.env.company, required=True)
   
    attachment = fields.Binary(string="Upload Attachment file", required=True)
    attachment_name = fields.Char(string='File Name')
    note = fields.Text('Notes')
    period = fields.Char('Period', compute="_compute_period")



    @api.model
    def create(self, vals):
        if vals['requested_position'] == self.contract_id.job_id or vals['requested_department'] ==  self.department_id:
            raise UserError(('Already in Position'))

        # list_of_uploaded_files = os.listdir()
        # print(list_of_uploaded_files)
        print(self.period)
        vals['state'] = 'in_progress'
        request = super(HrEmployeeRequest, self).create(vals)
        return request

    def hr_button_approve(self):
        self.write({'state':'hr_approval'})

    def manager_button_approve(self):
        approved_contract = self.contract_id
        self.contract_id.job_id = self.requested_position
        self.contract_id.department_id = self.requested_department
        self.department_id = self.requested_department
        self.write({'state':'manager_approval'})

        

    def button_reject(self):
        self.write({'state':'rejected'})

    def button_close(self):
        self.write({'state':'closed'})

    @api.depends("contract_id")
    def _compute_period(self):
        fmt = '%Y-%m-%d'
        start_date = self.contract_id.date_start
        dateStr = start_date.strftime(fmt)
        end_date = datetime.date.today().strftime('%Y-%m-%d')
        d1 = datetime.datetime.strptime(dateStr, fmt)
        d2 = datetime.datetime.strptime(end_date, fmt)
        self.period = (d2 - d1).days