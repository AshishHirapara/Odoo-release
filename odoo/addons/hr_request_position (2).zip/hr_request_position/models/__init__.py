# -*- coding: utf-8 -*-

from . import hr_employee_request
from . import hr_job
from . import hr_contract